# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["BetaComputerUsePreviewToolParam"]


class BetaComputerUsePreviewToolParam(TypedDict, total=False):
    """A tool that controls a virtual computer.

    Learn more about the [computer tool](https://developers.openai.com/api/docs/guides/tools-computer-use).
    """

    display_height: Required[int]
    """The height of the computer display."""

    display_width: Required[int]
    """The width of the computer display."""

    environment: Required[Literal["windows", "mac", "linux", "ubuntu", "browser"]]
    """The type of computer environment to control."""

    type: Required[Literal["computer_use_preview"]]
    """The type of the computer use tool. Always `computer_use_preview`."""
