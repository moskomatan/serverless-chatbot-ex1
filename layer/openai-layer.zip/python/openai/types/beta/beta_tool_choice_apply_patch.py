# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["BetaToolChoiceApplyPatch"]


class BetaToolChoiceApplyPatch(BaseModel):
    """Forces the model to call the apply_patch tool when executing a tool call."""

    type: Literal["apply_patch"]
    """The tool to call. Always `apply_patch`."""
